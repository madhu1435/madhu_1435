package Storetest.utill;

import java.lang.reflect.Array;
import java.util.Scanner;

import com.storetest.StoreTest;
import com.storetest.Test;

public class StoreTestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter storetest name ");
		StoreTest st=new StoreTest(sc.next());
		for(int i=0;i<2;i++){
			System.out.println("enter id,type,holder,amount");
			Test test=new Test(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());
			st.openTest(test);			
		}
		System.out.println("elements of array List before removing "+st.getArray().size());
		System.out.println("enter id of the account to be removed");
		st.closeTest(sc.nextInt());
		System.out.println("elements of array List after removing "+st.getArray().size());
		System.out.println("eneter id and amount to be deposited");
		st.deposit(sc.nextInt(),sc.nextDouble());
        st.display();
  
	}

}
