package com.storetest;
public class InputException extends Exception {

	public InputException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}

}
