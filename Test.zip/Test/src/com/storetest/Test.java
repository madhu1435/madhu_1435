package com.storetest;
public class Test {

	private int testID; 
private String testType; 
private  String testHolder;
private double testBalance;
public Test(int testID, String testType, String testHolder, double testBalance) {
	super();
	if(testID>=1 && testID<=1000)
	this.testID = testID;
	else
		try {
			throw new InputException("testID must be between 1 and 1000");
		} catch (InputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(testType.equalsIgnoreCase("abc")|| testType.equalsIgnoreCase("def"))
	this.testType = testType;
	else
		try {
			throw new InputException("testType must be either abc or def");
		} catch (InputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(testHolder.length()>=0)
	this.testHolder = testHolder;
	else
		try {
			throw new InputException("testHolder must not be empty");
		} catch (InputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(testBalance>=1000)
	this.testBalance = testBalance;
	else
		try {
			throw new InputException("balance must be greater than 1000");
		} catch (InputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
public int getTestID() {
	return testID;
}
public void setTestID(int testID) {
	this.testID = testID;
}
public String getTestType() {
	return testType;
}
public void setTestType(String testType) {
	this.testType = testType;
}
public String getTestHolder() {
	return testHolder;
}
public void setTestHolder(String testHolder) {
	this.testHolder = testHolder;
}
public double getTestBalance() {
	return testBalance;
}
public void setTestBalance(double testBalance) {
	this.testBalance = testBalance;
}
@Override
public String toString() {
	return "Test [testID=" + testID + ", testType=" + testType
			+ ", testHolder=" + testHolder + ", testBalance=" + testBalance
			+ "]";
} 


}
