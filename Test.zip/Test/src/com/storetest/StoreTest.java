package com.storetest;
import java.util.ArrayList;
import java.util.Scanner;

public class StoreTest {
	private String storetestName;

	public StoreTest(String storetestName) {
		super();
		this.storetestName = storetestName;
	}

	public String getStoretestName() {
		return storetestName;
	}

	public void setStoretestName(String storetestName) {
		this.storetestName = storetestName;
	}
	Scanner sc=new Scanner(System.in);
	ArrayList<Test>array=new ArrayList<Test>();
	public ArrayList<Test> getArray() {
		return array;
	}

	public void setArray(ArrayList<Test> array) {
		this.array = array;
	}

	//Test test1=new Test(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());
	public void openTest(Test test1){
		
		array.add(test1);
		}
	public void closeTest(int testId){
		Test a = null;
		for(Test t:array){
			if(t.getTestID()==testId){
			 a=t;
			}
		}
		array.remove(a);
		}
	public void deposit(int testId,double amt){
		int count=0;
		for(Test t:array){
			if(t.getTestID()==testId){
				count++;
				double amtf=t.getTestBalance()+amt;
				t.setTestBalance(amtf);
				
			}
			}
		if(count==0)
			System.out.println("account not found");
		
	}
	public void display(){
		for(Test t:array){
		System.out.println(t.toString());
		}
	}
	
	

}
