package Storetest.utill;

import java.lang.reflect.Array;
import java.util.Scanner;

import com.storetest.Account;
import com.storetest.BankName;

public class AccountDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter bank name ");
		BankName st=new BankName(sc.next());
		for(int i=0;i<3;i++){
			System.out.println("enter Account id,Account type,Account holder's Name,Amount");
			Account acc=new Account(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());
			st.openAcc(acc);			
		}
		System.out.println("elements of array List before removing "+st.getArray().size());
		System.out.println("enter Accid of the account to be removed");
		st.closeAcc(sc.nextInt());
		System.out.println("elements of array List after removing "+st.getArray().size());
		System.out.println("eneter Accid and amount to be deposited");
		st.deposit(sc.nextInt(),sc.nextDouble());
        st.display();
  
	}

}
