package com.storetest;
public class Account {

	private int AccID; 
private String AccType; 
private  String AccHolder;
private double AccBalance;
public Account(int AccID, String AccType, String AccHolder, double AccBalance) {
	super();
	if(AccID>=1 && AccID<=1000)
	this.AccID = AccID;
	else
		try {
			throw new InputException("AccID must be between 1 and 1000");
		} catch (InputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(AccType.equalsIgnoreCase("savings")|| AccType.equalsIgnoreCase("current"))
	this.AccType = AccType;
	else
		try {
			throw new InputException("testType must be either abc or def");
		} catch (InputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(AccHolder.length()>=0)
	this.AccHolder = AccHolder;
	else
		try {
			throw new InputException("AccHolder must not be empty");
		} catch (InputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(AccBalance>=1000)
	this.AccBalance = AccBalance;
	else
		try {
			throw new InputException("balance must be greater than 1000");
		} catch (InputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
public int getAccID() {
	return AccID;
}
public void setAccID(int AccID) {
	this.AccID = AccID;
}
public String getAccType() {
	return AccType;
}
public void setTestType(String AccType) {
	this.AccType = AccType;
}
public String getAccHolder() {
	return AccHolder;
}
public void setAccHolder(String AccHolder) {
	this.AccHolder = AccHolder;
}
public double getAccBalance() {
	return AccBalance;
}
public void setAccBalance(double AccBalance) {
	this.AccBalance = AccBalance;
}
@Override
public String toString() {
	return "Account [AccID=" + AccID + ", AccType=" + AccType + ", AccHolder="
			+ AccHolder + ", AccBalance=" + AccBalance + "]";
}



}
