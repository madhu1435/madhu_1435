package com.storetest;
import java.util.ArrayList;
public class BankName {
	private String bankName;

	public BankName(String bankName ) {
		super();
		this.bankName = bankName;
	}

	public String getBankName() {
		return bankName;
	}

	public void bankName(String bankName) {
		this.bankName = bankName;
	}
	ArrayList<Account>array=new ArrayList<Account>();
	
	public ArrayList<Account> getArray() {
		return array;
	}

	public void setArray(ArrayList<Account> array) {
		this.array = array;
	}

	public void openAcc(Account acc1){
		array.add(acc1);
		}
	public void closeAcc(int Id){
		Account a = null;
		for(Account t:array){
			if(t.getAccID()==Id){
			 a=t;
			}
		}
		array.remove(a);
		}
	public void deposit(int AccId,double amt){
		int count=0;
		for(Account t:array){
			if(t.getAccID()==AccId){
				count++;
				double amtf=t.getAccBalance()+amt;
				t.setAccBalance(amtf);
				
			}
			}
		if(count==0)
			System.out.println("account not found");
		
	}
	public void display(){
		for(Account t:array){
		System.out.println(t.toString());
		}
	}
	
	

}
